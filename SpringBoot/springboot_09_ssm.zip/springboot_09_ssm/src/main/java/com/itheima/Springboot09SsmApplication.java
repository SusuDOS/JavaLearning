package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * springboot整合mybatis框架完整演示代码.
 */


@SpringBootApplication
public class Springboot09SsmApplication {
    public static void main(String[] args) {
        SpringApplication.run(Springboot09SsmApplication.class, args);
    }

}
