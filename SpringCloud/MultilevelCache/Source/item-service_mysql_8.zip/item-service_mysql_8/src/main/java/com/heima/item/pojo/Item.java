package com.heima.item.pojo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;

import javax.persistence.Column;
import java.util.Date;

@Data
@TableName("tb_item")
public class Item {
    @TableId(type = IdType.AUTO)
    @Id
    private Long id;// 商品id,标记一下id.
    @Column(name = "name")
    private String name;// 商品名称,名称不一样需要映射.
    private String title;// 商品标题
    private Long price;// 价格（分）
    private String image;// 商品图片
    private String category;// 分类名称
    private String brand;// 品牌名称
    private String spec;// 规格
    private Integer status;// 商品状态 1-正常，2-下架
    private Date createTime;// 创建时间
    private Date updateTime;// 更新时间
    @TableField(exist = false)
    @Transient
    private Integer stock;
    @TableField(exist = false)
    @Transient
    private Integer sold;
}
