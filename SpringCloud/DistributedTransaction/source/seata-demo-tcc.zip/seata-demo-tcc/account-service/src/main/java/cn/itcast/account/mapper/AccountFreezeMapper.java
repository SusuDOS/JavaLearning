package cn.itcast.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import cn.itcast.account.entity.AccountFreeze;

/**
 * @author 虎哥
 */
public interface AccountFreezeMapper extends BaseMapper<AccountFreeze> {
}
