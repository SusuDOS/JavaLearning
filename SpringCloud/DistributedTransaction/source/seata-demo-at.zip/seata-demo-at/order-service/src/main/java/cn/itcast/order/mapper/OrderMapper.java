package cn.itcast.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import cn.itcast.order.entity.Order;

/**
 * @author 虎哥
 */
public interface OrderMapper extends BaseMapper<Order> {
}
