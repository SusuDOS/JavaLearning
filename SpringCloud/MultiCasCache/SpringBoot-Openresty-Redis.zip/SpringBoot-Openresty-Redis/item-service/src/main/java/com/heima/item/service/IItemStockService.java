package com.heima.item.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.heima.item.pojo.ItemStock;

// 我的印象中，主要是方便使用一些常用的方法实现了map，而IService不使用.
public interface IItemStockService extends IService<ItemStock> {
}
