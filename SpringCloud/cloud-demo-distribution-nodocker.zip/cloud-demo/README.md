## SpringCloud

- 服务分拆转为微服务结构
- 普通调用RestTemplate方式调用，非docker版本
- 调用方式为RestTemplate调用